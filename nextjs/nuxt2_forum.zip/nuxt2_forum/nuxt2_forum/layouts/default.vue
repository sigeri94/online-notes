<template>
  <div>
    <header class="site-header">
      <div class="brand">
        <div class="logo">CF</div>
        <div>
          <div class="site-title">CyberForum</div>
          <div class="site-sub" style="color:var(--muted);font-size:12px">Gaming community</div>
        </div>
      </div>
      <div class="nav-actions">
        <nuxt-link to="/">Home</nuxt-link>
        <template v-if="!user">
          <nuxt-link to="/login">Login</nuxt-link>
          <nuxt-link to="/register" class="btn btn-primary">Register</nuxt-link>
        </template>
        <template v-else>
          <nuxt-link to="/create-thread" class="btn btn-primary">Create Thread</nuxt-link>
          <button @click="logout" class="btn">Logout</button>
        </template>
      </div>
    </header>

    <main class="container">
      <nuxt />
    </main>
    <footer class="container footer-note">© CyberForum</footer>
  </div>
</template>

<script>
export default {
  data(){ return { user: null } },
  mounted(){ this.user = process.browser ? JSON.parse(localStorage.getItem('user') || 'null') : null; window.addEventListener('storage', ()=>{ this.user = JSON.parse(localStorage.getItem('user') || 'null') }) },
  methods:{ logout(){ localStorage.removeItem('user'); this.user = null; this.$router.push('/') } }
}
</script>
