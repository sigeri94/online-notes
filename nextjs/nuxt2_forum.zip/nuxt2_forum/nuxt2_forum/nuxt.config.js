export default {
  ssr: false,
  head: {
    title: 'CyberForum',
    meta: [{ charset: 'utf-8' }, { name: 'viewport', content: 'width=device-width, initial-scale=1' }]
  },
  css: ['~/assets/css/h2o-theme.css'],
  modules: ['@nuxtjs/axios', '@nuxtjs/dotenv'],
  plugins: ['~/plugins/axios.js'],
  serverMiddleware: [{ path: '/api', handler: '~/api/index.js' }]
}
