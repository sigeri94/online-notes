<template>
  <div>
    <h2>Create New Thread</h2>
    <form @submit.prevent="createThread">
      <div class="form-group">
        <label>Title</label>
        <input v-model="title" required />
      </div>
      <div class="form-group">
        <label>Content</label>
        <textarea v-model="content" rows="6" required></textarea>
      </div>
      <button type="submit" class="btn">Post Thread</button>
    </form>
  </div>
</template>

<script>
import axios from 'axios'
export default {
  data() {
    return {
      title: '',
      content: '',
      user: process.browser ? JSON.parse(localStorage.getItem('user') || 'null') : null
    }
  },
  methods: {
    async createThread() {
      if (!this.user) {
        alert('Please login first')
        this.$router.push('/login')
        return
      }
      try {
        await axios.post('/api/threads', {
          title: this.title,
          content: this.content,
          user_id: this.user.id
        })
        alert('Thread created successfully!')
        this.$router.push('/')
      } catch (err) {
        alert(err.response?.data?.error || 'Failed to create thread')
      }
    }
  }
}
</script>

<style>
h2 {
  margin-bottom: 15px;
}
.form-group {
  margin-bottom: 15px;
}
label {
  display: block;
  margin-bottom: 5px;
  font-weight: bold;
}
input, textarea {
  width: 100%;
  padding: 8px;
  border: 1px solid #ccc;
  border-radius: 5px;
  font-size: 15px;
  resize: vertical;
}
input:focus, textarea:focus {
  outline: none;
  border-color: #007bff;
  box-shadow: 0 0 3px rgba(0,123,255,0.5);
}
.btn {
  background: #007bff;
  color: white;
  padding: 10px 16px;
  border: none;
  border-radius: 6px;
  cursor: pointer;
  font-size: 15px;
}
.btn:hover {
  background: #0056b3;
}
</style>

