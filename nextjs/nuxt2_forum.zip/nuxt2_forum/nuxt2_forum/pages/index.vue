<template>
  <div>
    <div v-if="!user">
      <p>Welcome to the forum! Please login or register to start posting.</p>
      <NuxtLink to="/login" class="btn">Login</NuxtLink>
      <NuxtLink to="/register" class="btn">Register</NuxtLink>
    </div>
    <div v-else>
      <h2>Forum Threads</h2>
      <div v-for="thread in threads" :key="thread.id" class="thread-card">
        <NuxtLink :to="`/thread/${thread.id}`">{{ thread.title }}</NuxtLink>
        <p>by {{ thread.username }}</p>
      </div>

      <div class="pagination">
        <button @click="prevPage" :disabled="page === 1">Prev</button>
        <span>Page {{ page }}</span>
        <button @click="nextPage" :disabled="threads.length < 10">Next</button>
      </div>
    </div>
  </div>
</template>

<script>
import axios from 'axios'
export default {
  data() {
    return {
      threads: [],
      page: 1,
      user: process.browser ? JSON.parse(localStorage.getItem('user') || 'null') : null
    }
  },
  mounted() {
    this.fetchThreads()
  },
  methods: {
    async fetchThreads() {
      const res = await axios.get(`/api/threads?page=${this.page}`)
      this.threads = res.data
    },
    nextPage() {
      this.page++
      this.fetchThreads()
    },
    prevPage() {
      this.page--
      this.fetchThreads()
    }
  }
}
</script>

<style>
.thread-card {
  border-bottom: 1px solid #ddd;
  padding: 10px 0;
}
.thread-card a {
  font-size: 18px;
  font-weight: bold;
  color: #007bff;
  text-decoration: none;
}
.thread-card a:hover {
  text-decoration: underline;
}
.pagination {
  display: flex;
  justify-content: space-between;
  margin-top: 20px;
}
.pagination button {
  padding: 6px 10px;
  background: #007bff;
  border: none;
  color: #fff;
  border-radius: 5px;
  cursor: pointer;
}
.pagination button:disabled {
  background: #ccc;
  cursor: not-allowed;
}
</style>

