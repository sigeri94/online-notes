<template>
  <div class="thread-container">
    <div v-if="thread" class="thread-card">
      <h1 class="thread-title">{{ thread.title }}</h1>
      <p class="thread-content">{{ thread.content }}</p>
      <p class="thread-meta">by <b>{{ thread.username }}</b></p>
    </div>

    <div class="replies-section">
      <h3>Replies</h3>
      <div v-if="replies.length" class="reply-list">
        <div v-for="r in replies" :key="r.id" class="reply-card">
          <p class="reply-content">{{ r.content }}</p>
          <small class="reply-meta">by <b>{{ r.username }}</b></small>
        </div>
      </div>
      <div v-else class="no-replies">No replies yet.</div>

      <div class="reply-form">
        <textarea v-model="replyContent" placeholder="Write a reply..."></textarea>
        <button @click="sendReply">Send</button>
      </div>
    </div>
  </div>
</template>

<script>
export default {
  data() {
    return { thread: null, replies: [], replyContent: '' }
  },
  async fetch() {
    const res = await this.$axios.$get('/api/threads/' + this.$route.params.id)
    this.thread = res.thread
    this.replies = res.replies
  },
  methods: {
    async sendReply() {
      const user = JSON.parse(localStorage.getItem('user'))
      if (!user) { alert('Login first'); return }
      await this.$axios.$post('/api/threads/' + this.$route.params.id + '/reply', {
        content: this.replyContent,
        user_id: user.id
      })
      this.replyContent = ''
      location.reload()
    }
  }
}
</script>

<style>
.thread-container {
  max-width: 700px;
  margin: 40px auto;
  padding: 20px;
  background: #fff;
  border-radius: 8px;
  box-shadow: 0 2px 6px rgba(0, 0, 0, 0.1);
  font-family: Arial, sans-serif;
  color: #333;
}

.thread-title {
  font-size: 1.6em;
  color: #222;
  margin-bottom: 10px;
}

.thread-content {
  font-size: 1.1em;
  line-height: 1.5;
  margin-bottom: 8px;
}

.thread-meta {
  color: #777;
  font-size: 0.9em;
  margin-bottom: 20px;
}

.replies-section h3 {
  border-top: 1px solid #ddd;
  padding-top: 15px;
  margin-top: 20px;
  font-size: 1.2em;
}

.reply-card {
  background: #f9f9f9;
  border: 1px solid #e5e5e5;
  padding: 10px 12px;
  border-radius: 6px;
  margin-bottom: 10px;
}

.reply-content {
  margin: 0 0 5px 0;
}

.reply-meta {
  color: #666;
  font-size: 0.85em;
}

.reply-form {
  display: flex;
  flex-direction: column;
  margin-top: 20px;
}

.reply-form textarea {
  resize: vertical;
  min-height: 80px;
  padding: 8px;
  font-size: 1em;
  border: 1px solid #ccc;
  border-radius: 6px;
  margin-bottom: 10px;
}

.reply-form button {
  align-self: flex-end;
  background: #4caf50;
  color: white;
  border: none;
  padding: 8px 16px;
  border-radius: 6px;
  cursor: pointer;
}

.reply-form button:hover {
  background: #45a049;
}

.no-replies {
  color: #777;
  font-style: italic;
  margin-bottom: 15px;
}
</style>

