
export default function({ $axios }) {
  $axios.defaults.baseURL = '/'
}
