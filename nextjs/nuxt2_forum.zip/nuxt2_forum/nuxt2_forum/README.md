
# Nuxt2 Forum (Fixed Flow)

## Run locally
1. Create MySQL database using `db/schema.sql`
2. Copy `.env.example` to `.env` and edit DB credentials
3. Install dependencies
   ```bash
   npm install
   ```
4. Start development
   ```bash
   npm run dev
   ```
Then open http://localhost:3000
