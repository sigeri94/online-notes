
const express = require('express')
const mysql = require('mysql2/promise')
require('dotenv').config()

const app = express()
app.use(express.json())

const pool = mysql.createPool({
  host: process.env.DB_HOST,
  user: process.env.DB_USER,
  password: process.env.DB_PASS,
  database: process.env.DB_NAME
})

// Register
app.post('/register', async (req, res) => {
  const { username, password } = req.body
  if (!username || !password) return res.status(400).json({ error: 'Missing fields' })
  try {
    const [rows] = await pool.query('INSERT INTO users (username, password) VALUES (?, ?)', [username, password])
    res.json({ id: rows.insertId, username })
  } catch (e) {
    res.status(400).json({ error: e.message })
  }
})

// Login
app.post('/login', async (req, res) => {
  const { username, password } = req.body
  const [rows] = await pool.query('SELECT * FROM users WHERE username = ?', [username])
  if (rows.length === 0) return res.status(401).json({ error: 'Invalid username' })
  const user = rows[0]
  if (user.password !== password) return res.status(401).json({ error: 'Invalid password' })
  res.json({ id: user.id, username: user.username })
})

// Threads
app.get('/threads', async (req, res) => {
  const page = parseInt(req.query.page) || 1
  const limit = 10
  const offset = (page - 1) * limit
  const [threads] = await pool.query('SELECT threads.*, users.username FROM threads JOIN users ON threads.user_id = users.id ORDER BY threads.created_at DESC LIMIT ? OFFSET ?', [limit, offset])
  res.json(threads)
})

// Create thread
app.post('/threads', async (req, res) => {
  const { title, content, user_id } = req.body
  if (!title || !content || !user_id) return res.status(400).json({ error: 'Missing fields' })
  const [result] = await pool.query('INSERT INTO threads (title, content, user_id) VALUES (?, ?, ?)', [title, content, user_id])
  res.json({ id: result.insertId })
})

// Thread detail + replies
app.get('/threads/:id', async (req, res) => {
  const [threadRows] = await pool.query('SELECT threads.*, users.username FROM threads JOIN users ON threads.user_id = users.id WHERE threads.id = ?', [req.params.id])
  if (threadRows.length === 0) return res.status(404).json({ error: 'Thread not found' })
  const [replies] = await pool.query('SELECT replies.*, users.username FROM replies JOIN users ON replies.user_id = users.id WHERE thread_id = ? ORDER BY created_at ASC', [req.params.id])
  res.json({ thread: threadRows[0], replies })
})

// Reply
app.post('/threads/:id/reply', async (req, res) => {
  const { content, user_id } = req.body
  const [result] = await pool.query('INSERT INTO replies (thread_id, content, user_id) VALUES (?, ?, ?)', [req.params.id, content, user_id])
  res.json({ id: result.insertId })
})

module.exports = app
