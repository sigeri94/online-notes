// pages/api/logout.js
export default function handler(req, res) {
  // Clear cookie
  res.setHeader('Set-Cookie', `token=; HttpOnly; Path=/; Max-Age=0`)
  res.status(200).json({ ok: true })
}
