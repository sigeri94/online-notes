// pages/api/register.js
// DEMO: stores plaintext passwords in MySQL (intentionally insecure)
import jwt from 'jsonwebtoken'
import { query } from '../../lib/db'

const SECRET = process.env.JWT_SECRET || 'supersecret_local_dev_key'

export default async function handler(req, res) {
  if (req.method === 'GET') {
    res.setHeader('Content-Type', 'text/html; charset=utf-8')
    res.status(200).send(`
      <html><body style="font-family: Inter, system-ui, -apple-system; padding:20px;">
        <h1>Register (Demo)</h1>
        <form method="post" action="/api/register">
          <div><label>Username: <input name="username" /></label></div>
          <div style="margin-top:8px"><label>Password: <input name="password" type="password" /></label></div>
          <div style="margin-top:12px"><button type="submit">Register</button></div>
        </form>
        <p>Note: this demo stores plaintext passwords (insecure).</p>
      </body></html>
    `)
    return
  }

  if (req.method === 'POST') {
    const contentType = (req.headers['content-type'] || '')
    let username = ''
    let password = ''

    if (contentType.includes('application/json')) {
      username = (req.body && req.body.username) || ''
      password = (req.body && req.body.password) || ''
    } else {
      username = (req.body && req.body.username) || ''
      password = (req.body && req.body.password) || ''
    }

    username = String(username || '').trim()
    password = String(password || '')

    if (!username || !password) {
      res.status(400).send('username and password required')
      return
    }

    try {
      // Check existing user
      const users = await query('SELECT id FROM users WHERE username = ? LIMIT 1', [username])
      if (users.length > 0) {
        res.setHeader('Content-Type', 'text/html; charset=utf-8')
        res.status(409).send(`
          <html><body style="font-family: Inter, system-ui, -apple-system; padding:20px;">
            <h1>Register failed</h1>
            <p>User <strong>${username}</strong> already exists.</p>
            <p><a href="/api/register">Back</a></p>
          </body></html>
        `)
        return
      }

      // Insert user (insecure: plaintext password)
      await query('INSERT INTO users (username, password) VALUES (?, ?)', [username, password])

      // Auto-login: create JWT and set cookie
      const token = jwt.sign({ username }, SECRET, { expiresIn: '1h' })
      // Cookie for demo: HttpOnly, Path, Max-Age (not Secure)
      res.setHeader('Set-Cookie', `token=${token}; HttpOnly; Path=/; Max-Age=3600`)

      res.setHeader('Content-Type', 'text/html; charset=utf-8')
      res.status(201).send(`
        <html><body style="font-family: Inter, system-ui, -apple-system; padding:20px;">
          <h1>Registered</h1>
          <p>Account <strong>${username}</strong> created (demo).</p>
          <p><a href="/">Go to home</a></p>
        </body></html>
      `)
    } catch (err) {
      console.error('register error', err)
      res.status(500).json({ error: 'internal error' })
    }
    return
  }

  res.setHeader('Allow', 'GET, POST')
  res.status(405).end('Method Not Allowed')
}

