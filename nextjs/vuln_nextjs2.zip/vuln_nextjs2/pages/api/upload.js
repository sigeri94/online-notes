// pages/api/upload.js
import { formidable } from 'formidable'
import fs from 'fs'
import path from 'path'

export const config = {
  api: { bodyParser: false },
}

const uploadDir = path.join(process.cwd(), 'public', 'uploads')
if (!fs.existsSync(uploadDir)) fs.mkdirSync(uploadDir, { recursive: true })

export default function handler(req, res) {
  if (req.method !== 'POST') {
    res.setHeader('Allow', 'POST')
    return res.status(405).end('Method Not Allowed')
  }

  const form = formidable({ multiples: false, uploadDir, keepExtensions: true })

  form.parse(req, (err, fields, files) => {
    if (err) {
      console.error('Upload parse error:', err)
      return res.status(500).json({ error: 'Upload failed' })
    }

    // Get the uploaded file (assuming <input name="file" />)
    const file = files.file
    let filePath

    // Handle formidable v3 structure (array or object)
    if (Array.isArray(file)) filePath = file[0]?.filepath || file[0]?.path
    else filePath = file?.filepath || file?.path

    if (!filePath) {
      console.error('No file path returned from formidable:', file)
      return res.status(500).json({ error: 'File path undefined' })
    }

    const fileName = path.basename(filePath)
    const relPath = '/uploads/' + fileName

    console.log('Uploaded:', relPath)
    res.status(200).json({ success: true, file: relPath })
  })
}

