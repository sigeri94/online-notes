// pages/api/echo.js
// Intentionally vulnerable: reflects unsanitized user input into HTML


export default function handler(req, res) {
const { msg = 'hello' } = req.query
// Dangerous: returning a string that may contain HTML/JS
res.setHeader('Content-Type', 'text/html; charset=utf-8')
res.status(200).send(`
<html><body>
<h1>Echo</h1>
<div id="msg">${msg}</div>
</body></html>
`)
}