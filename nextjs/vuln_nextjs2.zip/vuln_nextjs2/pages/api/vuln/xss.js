// pages/vuln/xss.js
import Link from 'next/link'
import { useState } from 'react'

export default function XSSPage({ q }) {
  const [val, setVal] = useState(q || '')

  async function submit(e) {
    e.preventDefault()
    // reflect via query param navigation
    window.location.href = '/vuln/xss?q=' + encodeURIComponent(val)
  }

  return (
    <main style={{ padding: 24, fontFamily: 'Inter,system-ui' }}>
      <h1>Reflected XSS Demo (VULNERABLE)</h1>
      <p>Enter any HTML/JS and it will be reflected back without sanitization.</p>

      <form onSubmit={submit}>
        <textarea value={val} onChange={e => setVal(e.target.value)} rows={6} cols={60} />
        <div style={{ marginTop: 12 }}>
          <button type="submit">Reflect</button>
        </div>
      </form>

      <section style={{ marginTop: 20 }}>
        <h3>Reflected Output (unsanitized)</h3>
        <div dangerouslySetInnerHTML={{ __html: q || '' }} style={{ border: '1px solid #ccc', padding: 12 }} />
      </section>

      <p><Link href="/vuln">Back to vuln index</Link></p>
    </main>
  )
}

// Read query param on server side and pass to component
export async function getServerSideProps(ctx) {
  const q = ctx.query.q || ''
  return { props: { q } }
}

