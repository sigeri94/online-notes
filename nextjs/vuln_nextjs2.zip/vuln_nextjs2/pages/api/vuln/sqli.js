// pages/api/vuln/sqli.js
// INTENTIONALLY VULNERABLE: performs SQL by interpolating user input directly.
// This version returns the constructed SQL and any SQL error instead of crashing.
import { query } from '../../../lib/db'

export default async function handler(req, res) {
  if (req.method !== 'POST') {
    res.setHeader('Allow', 'POST')
    return res.status(405).end('Method Not Allowed')
  }

  const { username = '' } = req.body || {}

  // Construct the vulnerable SQL (DO NOT use this pattern in real apps)
  const sql = `SELECT id, username, password FROM users WHERE username = '${username}' LIMIT 10`

  try {
    // Attempt the query (this is vulnerable to SQL injection)
    const rows = await query(sql)
    res.setHeader('Content-Type', 'text/html; charset=utf-8')
    res.status(200).send(`${JSON.stringify(rows, null, 2)}`)
  } catch (err) {
    res.status(500).json({ error: 'internal' })
  }
}

