// pages/api/login.js
import jwt from 'jsonwebtoken'
import { query } from '../../lib/db'

const SECRET = process.env.JWT_SECRET || 'supersecret_local_dev_key'

export default async function handler(req, res) {
  if (req.method === 'GET') {
    res.setHeader('Content-Type', 'text/html; charset=utf-8')
    res.status(200).send(`
    `)
    return
  }

  if (req.method === 'POST') {
    const contentType = (req.headers['content-type'] || '')
    let username = ''
    let password = ''

    if (contentType.includes('application/json')) {
      username = (req.body && req.body.username) || ''
      password = (req.body && req.body.password) || ''
    } else {
      username = (req.body && req.body.username) || ''
      password = (req.body && req.body.password) || ''
    }

    username = String(username || '')
    password = String(password || '')

    try {
      const rows = await query('SELECT id, username, password FROM users WHERE username = ? LIMIT 1', [username])
      const user = rows && rows[0]
      if (!user || user.password !== password) {
        res.setHeader('Content-Type', 'text/html; charset=utf-8')
        res.status(401).send(`
          <html><body style="font-family: Inter, system-ui, -apple-system; padding:20px;">
            <h1>Login failed</h1>
            <p>Invalid username or password.</p>
            <p><a href="/api/login">Try again</a></p>
          </body></html>
        `)
        return
      }

      const token = jwt.sign({ username: user.username }, SECRET, { expiresIn: '1h' })
      res.setHeader('Set-Cookie', `token=${token}; HttpOnly; Path=/; Max-Age=3600`)
      res.setHeader('Content-Type', 'text/html; charset=utf-8')
      res.status(200).send(`
        <html><body style="font-family: Inter, system-ui, -apple-system; padding:20px;">
          <h1>Login successful</h1>
          <p>Welcome, <strong>${user.username}</strong></p>
          <p><a href="/">Home</a></p>
        </body></html>
      `)
    } catch (err) {
      console.error('login error', err)
      res.status(500).json({ error: 'internal error' })
    }
    return
  }

  res.setHeader('Allow', 'GET, POST')
  res.status(405).end('Method Not Allowed')
}

