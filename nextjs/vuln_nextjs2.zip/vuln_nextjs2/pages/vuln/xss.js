// pages/vuln/xss.js
import Link from 'next/link'
import { useState } from 'react'

export default function XSSPage({ q }) {
  const [val, setVal] = useState(q || '')

  function submit(e) {
    e.preventDefault()
    // reflect via query param navigation (intentionally unsanitized)
    window.location.href = '/vuln/xss?q=' + encodeURIComponent(val)
  }

  return (
    <main style={{ padding: 24, fontFamily: 'Inter,system-ui' }}>
      <header style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center' }}>
        <h1>Reflected XSS Demo (VULNERABLE)</h1>
        <nav>
          <Link href="/">Home</Link> | <Link href="/profile">Profile</Link> | <Link href="/upload">Upload</Link> | <Link href="/vuln">Vuln</Link>
        </nav>
      </header>

      <p>Enter any HTML/JS and it will be reflected back without sanitization.</p>

      <form onSubmit={submit}>
        <textarea value={val} onChange={e => setVal(e.target.value)} rows={8} cols={80} />
        <div style={{ marginTop: 12 }}>
          <button type="submit">Reflect</button>
        </div>
      </form>

      <section style={{ marginTop: 20 }}>
        <h3>Reflected Output (unsanitized)</h3>
        <div
          dangerouslySetInnerHTML={{ __html: q || '' }}
        />
      </section>

    </main>
  )
}

export async function getServerSideProps(ctx) {
  const q = ctx.query.q || ''
  // pass raw query through (intentionally vulnerable)
  return { props: { q } }
}

