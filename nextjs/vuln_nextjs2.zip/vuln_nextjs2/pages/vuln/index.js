// pages/vuln/index.js
import Link from 'next/link'
export default function VulnIndex() {
  return (
    <main style={{ padding: 24, fontFamily: 'Inter,system-ui' }}>
      <h1>Vulnerable Examples</h1>
      <ul>
        <li><Link href="/vuln/sqli">SQL Injection (vulnerable)</Link></li>
        <li><Link href="/vuln/xss">Reflected XSS (vulnerable)</Link></li>
      </ul>
      <p><Link href="/">Back to Home</Link></p>
    </main>
  )
}

