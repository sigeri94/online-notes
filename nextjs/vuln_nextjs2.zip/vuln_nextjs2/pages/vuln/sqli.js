// pages/vuln/sqli.js
import { useState } from 'react'
import Link from 'next/link'

export default function SqliPage() {
  const [username, setUsername] = useState('')
  const [out, setOut] = useState('')

  async function submit(e) {
    e.preventDefault()
    const res = await fetch('/api/vuln/sqli', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ username })
    })
    const text = await res.text()
    setOut(text)
  }

  return (
    <main style={{ padding: 24, fontFamily: 'Inter,system-ui' }}>
      <h1>SQL Injection Demo (VULNERABLE)</h1>
      <p>This endpoint performs an unsafe SQL query using direct string interpolation.</p>
      <form onSubmit={submit}>
        <label>username: <input value={username} onChange={e => setUsername(e.target.value)} /></label>
        <div style={{ marginTop: 12 }}>
          <button type="submit">Lookup</button>
        </div>
      </form>

      <section style={{ marginTop: 20 }}>
        <h3>Result (raw)</h3>
        <pre style={{ whiteSpace: 'pre-wrap' }}>{out}</pre>
      </section>

      <p><Link href="/vuln">Back to vuln index</Link></p>
    </main>
  )
}

