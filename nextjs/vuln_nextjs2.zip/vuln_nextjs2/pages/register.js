// pages/register.js
import { useState } from 'react'
import { useRouter } from 'next/router'

export default function RegisterPage() {
  const router = useRouter()
  const [username, setUsername] = useState('')
  const [password, setPassword] = useState('')
  const [error, setError] = useState('')

  async function handleSubmit(e) {
    e.preventDefault()
    setError('')
    try {
      const res = await fetch('/api/register', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        credentials: 'same-origin', // important to accept/set HttpOnly cookie
        body: JSON.stringify({ username, password }),
      })
      if (res.ok || res.status === 201) {
        // success — the API sets the HttpOnly cookie; redirect to protected page
        router.push('/profile')
      } else {
        const txt = await res.text()
        setError(txt || `Register failed: ${res.status}`)
      }
    } catch (err) {
      setError(String(err))
    }
  }

  return (
    <main style={{ fontFamily: 'Inter,system-ui,-apple-system', padding: 24, maxWidth: 640, margin: '0 auto' }}>
      <h1>Register</h1>
      <form onSubmit={handleSubmit}>
        <div style={{ marginBottom: 12 }}>
          <label>Username<br />
            <input value={username} onChange={(e) => setUsername(e.target.value)} required />
          </label>
        </div>

        <div style={{ marginBottom: 12 }}>
          <label>Password<br />
            <input type="password" value={password} onChange={(e) => setPassword(e.target.value)} required />
          </label>
        </div>

        <div style={{ marginBottom: 12 }}>
          <button type="submit">Register</button>
        </div>

        {error && <div style={{ color: 'crimson' }}>{error}</div>}
      </form>

      <p>
        Already have an account? <a href="/login">Login</a>
      </p>
    </main>
  )
}

