// pages/index.js
import Link from 'next/link'
import { useEffect, useState } from 'react'

function getCookie(name) {
  const m = document.cookie.match('(^|;)\\s*' + name + '\\s*=\\s*([^;]+)')
  return m ? m.pop() : ''
}

export default function Home() {
  const [logged, setLogged] = useState(false)

  useEffect(() => {
    setLogged(!!getCookie('token'))
  }, [])

  return (
    <div style={styles.container}>
      <header style={styles.header}>
        <h1 style={styles.title}>🚨 Vulnerable Next.js App</h1>
        <p style={styles.subtitle}>
          This is a deliberately insecure demo for local testing only.
        </p>
      </header>

      <nav style={styles.nav}>
        {logged ? (
          <>
            <Link href="/profile" style={styles.link}>Profile</Link>
            <Link href="/upload" style={styles.link}>Upload</Link>
            <a href="#" onClick={async (e) => { e.preventDefault(); await fetch('/api/logout',{method:'POST', credentials:'same-origin'}); window.location.href='/'; }}>Logout</a>
          </>
        ) : (
          <>
            <Link href="/login" style={styles.link}>Login</Link>
            <Link href="/register" style={styles.link}>Register</Link>
          </>
        )}
      </nav>

      <main style={styles.main}>
        <p>
          Try logging in with any account created via the register page.
        </p>
      </main>

      <footer style={styles.footer}>
        <small>Demo app — files uploaded go to <code>/public/uploads</code></small>
      </footer>
    </div>
  )
}

const styles = {
  container: { display: 'flex', minHeight: '100vh', flexDirection: 'column', padding: 20 },
  header: { textAlign: 'center' },
  title: { margin: 0, fontSize: '1.6rem' },
  subtitle: { marginTop: 8, color: '#666' },
  nav: { display: 'flex', gap: 12, justifyContent: 'center', marginTop: 18 },
  link: { textDecoration: 'none', color: '#1d4ed8' },
  main: { marginTop: 40, textAlign: 'center' },
  footer: { marginTop: 'auto', padding: '20px', color: '#888', fontSize: '0.9rem' },
}

