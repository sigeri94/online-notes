// pages/upload.js
import { useState } from 'react'
import Router from 'next/router'
import Link from 'next/link'

export default function UploadPage() {
  const [file, setFile] = useState(null)
  const [msg, setMsg] = useState('')

  async function handleSubmit(e) {
    e.preventDefault()
    if (!file) {
      setMsg('Please choose a file first')
      return
    }
    const fd = new FormData()
    fd.append('file', file)
    const res = await fetch('/api/upload', { method: 'POST', body: fd })
    const j = await res.json()
    if (res.ok) {
      setMsg('Upload successful: ' + j.file)
    } else {
      setMsg('Upload failed: ' + (j.error || res.statusText))
    }
  }

  return (
    <main style={{ padding: 24, maxWidth: 800, margin: '0 auto', fontFamily: 'Inter, system-ui' }}>
      <header style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center' }}>
        <h1>Upload File</h1>
        <nav>
          <Link href="/profile">Profile</Link> | <Link href="/">Home</Link>
        </nav>
      </header>

      <form onSubmit={handleSubmit} style={{ marginTop: 20 }}>
        <input type="file" onChange={e => setFile(e.target.files[0])} />
        <div style={{ marginTop: 12 }}>
          <button type="submit">Upload</button>
        </div>
      </form>

      {msg && <p style={{ marginTop: 12 }}>{msg}</p>}
    </main>
  )
}

