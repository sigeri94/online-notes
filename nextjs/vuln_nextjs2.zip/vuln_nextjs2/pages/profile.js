// pages/profile.js
import jwt from 'jsonwebtoken'
import cookie from 'cookie'
import Link from 'next/link'

export default function Profile({ user }) {
  return (
    <main style={{ fontFamily: 'Inter,system-ui,-apple-system', padding: 24, maxWidth: 800, margin: '0 auto' }}>
      <header style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center' }}>
        <h1>Profile</h1>
        <nav>
          <Link href="/">Home</Link> | <Link href="/upload">Upload</Link> | <Link href="/vuln">Vuln</Link>
        </nav>
      </header>

      <p>Welcome, <strong>{user?.username}</strong></p>
      <p>Account created for demo purposes. This page is protected via server-side cookie verification.</p>
      <button
        onClick={async () => {
          await fetch('/api/logout', { method: 'POST', credentials: 'same-origin' })
          window.location.href = '/'
        }}
      >
        Logout
      </button>
    </main>
  )
}

export async function getServerSideProps(ctx) {
  const c = ctx.req.headers.cookie
  if (!c) {
    return {
      redirect: { destination: '/', permanent: false },
    }
  }
  const parsed = cookie.parse(c || '')
  const token = parsed.token
  if (!token) {
    return {
      redirect: { destination: '/', permanent: false },
    }
  }

  try {
    const secret = process.env.JWT_SECRET || 'supersecret_local_dev_key'
    const decoded = jwt.verify(token, secret)
    return { props: { user: { username: decoded.username } } }
  } catch (err) {
    // Invalid token
    return { redirect: { destination: '/', permanent: false } }
  }
}

