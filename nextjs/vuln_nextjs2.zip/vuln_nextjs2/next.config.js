// next.config.js
// Intentionally exposing a dev env var via public runtime config for demonstration
module.exports = {
reactStrictMode: false,
env: {
INSECURE_API_KEY: 'dev-only-EXPOSED_KEY'
}
}