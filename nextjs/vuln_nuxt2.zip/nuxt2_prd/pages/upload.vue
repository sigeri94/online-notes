<template>
  <div class="upload">
    <h2>File Upload (vulnerable)</h2>
    <form @submit.prevent="submit" enctype="multipart/form-data">
      <input type="file" ref="fileInput" />
      <br/>
      <button type="submit">Upload</button>
    </form>

    <p v-if="message" :style="{ color: messageColor }">{{ message }}</p>

    <ul v-if="files && files.length">
      <li v-for="f in files" :key="f">{{ f }}</li>
    </ul>
  </div>
</template>

<script>
import axios from 'axios'

export default {
  data() {
    return {
      message: '',
      messageColor: 'green',
      files: []
    }
  },
  methods: {
    async submit() {
      const el = this.$refs.fileInput
      if (!el || !el.files.length) {
        this.message = 'Please pick a file'
        this.messageColor = 'red'
        return
      }

      const form = new FormData()
      form.append('file', el.files[0])

      try {
        const res = await axios.post('/api/upload', form, {
          headers: { 'Content-Type': 'multipart/form-data' }
        })
        this.message = res.data.message || 'Uploaded'
        this.messageColor = 'green'
        if (res.data.files) this.files = res.data.files
      } catch (err) {
        this.message = err.response?.data?.message || 'Upload failed'
        this.messageColor = 'red'
      }
    }
  }
}
</script>

<style scoped>
.upload {
  max-width: 600px;
  margin: 40px auto;
  text-align: center;
}
button {
  margin-top: 10px;
}
</style>

