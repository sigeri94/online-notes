<template>
  <div class="login">
    <h2>Login</h2>
    <form @submit.prevent="login">
      <input v-model="username" type="text" placeholder="Username" required />
      <input v-model="password" type="password" placeholder="Password" required />
      <button type="submit">Login</button>
    </form>
    <p v-if="error" style="color:red">{{ error }}</p>
  </div>
</template>

<script>
import axios from 'axios'

export default {
  data() {
    return {
      username: '',
      password: '',
      error: ''
    }
  },
  methods: {
    async login() {
      this.error = ''
      try {
        const res = await axios.post('/api/login', {
          username: this.username,
          password: this.password
        })
        localStorage.setItem('token', res.data.token)
        await this.$nextTick()
        this.$router.replace('/profile')
      } catch (err) {
        this.error =
          err.response?.data?.message || 'Invalid username or password'
      }
    }
  },
  mounted() {
    const token = localStorage.getItem('token')
    if (token) {
      this.$router.replace('/profile')
    }
  }
}
</script>

<style scoped>
.login {
  text-align: center;
  margin-top: 40px;
}
</style>

