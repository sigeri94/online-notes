<template>
  <div class="profile">
    <h2>User Profile</h2>

    <div v-if="loading">Loading...</div>

    <div v-else-if="user">
      <p><b>ID:</b> {{ user.id }}</p>
      <p><b>Username:</b> {{ user.username }}</p>

      <nav class="links">
        <nuxt-link to="/upload">Upload</nuxt-link> |
        <nuxt-link to="/xss">XSS</nuxt-link> |
        <nuxt-link to="/sqli">SQLi</nuxt-link>
      </nav>

      <button @click="logout">Logout</button>
    </div>

    <div v-else>
      <p style="color: red">Failed to load profile. Redirecting...</p>
    </div>
  </div>
</template>

<script>
import axios from 'axios'

export default {
  data() {
    return {
      user: null,
      loading: true
    }
  },
  async mounted() {
    const token = localStorage.getItem('token')
    if (!token) {
      this.$router.push('/login')
      return
    }

    try {
      const res = await axios.get('/api/profile', {
        headers: { Authorization: `Bearer ${token}` }
      })
      this.user = res.data
    } catch (err) {
      console.error('Profile fetch error:', err)
      localStorage.removeItem('token')
      setTimeout(() => this.$router.push('/login'), 1000)
    } finally {
      this.loading = false
    }
  },
  methods: {
    logout() {
      localStorage.removeItem('token')
      this.$router.push('/')
    }
  }
}
</script>

<style scoped>
.profile {
  max-width: 600px;
  margin: 40px auto;
  text-align: center;
  padding: 20px;
  border: 1px solid #ddd;
  border-radius: 10px;
  background: #fafafa;
}
.links {
  margin: 16px 0;
}
.links a {
  margin: 0 6px;
}
button {
  margin-top: 12px;
  padding: 8px 16px;
  cursor: pointer;
}
</style>

