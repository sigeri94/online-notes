<template>
  <div class="xss">
    <h2>Reflected XSS Demo</h2>

    <p>
      Type something — it will be rendered as HTML (intentionally unsafe).
      Example: <code>&lt;img src=x onerror=alert('xss')/&gt;</code>
    </p>

    <textarea v-model="payload" rows="6" cols="60" placeholder="Enter HTML or script"></textarea>
    <br/>
    <button @click="render">Render</button>

    <h3>Output (rendered with v-html)</h3>
    <div class="output" v-html="rendered"></div>

    <h3>Raw value</h3>
    <pre>{{ payload }}</pre>
  </div>
</template>

<script>
export default {
  data() {
    return {
      payload: '',
      rendered: ''
    }
  },
  methods: {
    render() {
      // intentionally unsafe: direct assignment to v-html
      this.rendered = this.payload
    }
  }
}
</script>

<style scoped>
.xss {
  max-width: 800px;
  margin: 30px auto;
  text-align: left;
}
.output {
  min-height: 80px;
  padding: 10px;
  border: 1px solid #ddd;
  background: #fff;
}
textarea {
  width: 100%;
  box-sizing: border-box;
}
</style>

