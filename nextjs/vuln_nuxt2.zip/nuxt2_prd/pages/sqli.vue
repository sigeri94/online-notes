<template>
  <div class="sqli">
    <h2>SQLi Demo</h2>
    <p>Enter a username to search the DB (server endpoint runs an intentionally unsafe query).</p>

    <form @submit.prevent="search">
      <input v-model="username" type="text" placeholder="username" />
      <button type="submit">Search</button>
    </form>

    <p v-if="error" style="color: red">{{ error }}</p>

    <div v-if="loading">Loading...</div>

    <div v-else>
      <h3>Result</h3>
      <pre>{{ resultText }}</pre>
    </div>
  </div>
</template>

<script>
import axios from 'axios'

export default {
  data() {
    return {
      username: '',
      resultText: '',
      loading: false,
      error: ''
    }
  },
  methods: {
    async search() {
      this.error = ''
      this.resultText = ''
      this.loading = true
      try {
        const res = await axios.post('/api/sqli', { username: this.username })
        this.resultText = JSON.stringify(res.data, null, 2)
      } catch (err) {
        this.error = err.response?.data?.message || 'Query failed'
      } finally {
        this.loading = false
      }
    }
  }
}
</script>

<style scoped>
.sqli {
  max-width: 800px;
  margin: 30px auto;
  text-align: left;
}
input {
  margin-right: 6px;
}
</style>

