<template>
  <div class="container">
    <h1>Welcome</h1>
    <div v-if="!isLoggedIn">
      <nuxt-link to="/register">Register</nuxt-link> |
      <nuxt-link to="/login">Login</nuxt-link>
    </div>
    <div v-else>
      <nuxt-link to="/profile">Go to Profile</nuxt-link> |
      <a href="#" @click.prevent="logout">Logout</a>
    </div>
  </div>
</template>

<script>
export default {
  data() {
    return { isLoggedIn: false }
  },
  mounted() {
    this.isLoggedIn = !!localStorage.getItem('token')
  },
  methods: {
    logout() {
      localStorage.removeItem('token')
      this.isLoggedIn = false
      this.$router.push('/')
    }
  }
}
</script>

<style scoped>
.container {
  text-align: center;
  margin-top: 50px;
}
</style>

