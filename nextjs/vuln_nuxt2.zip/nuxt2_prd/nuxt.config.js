export default {
  head: {
    title: 'vuln_nuxt2',
    meta: [
      { charset: 'utf-8' },
      { name: 'viewport', content: 'width=device-width, initial-scale=1' }
    ]
  },

  css: [],
  components: true,
  modules: ['@nuxtjs/axios'],

  axios: {
    baseURL: '/' // all requests go to same server
  },

  // 👇 integrate backend into Nuxt directly
  serverMiddleware: [
    { path: '/', handler: '~/server/api.js' }
  ],

  build: {}
}

