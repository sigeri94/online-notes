// server/db.js
const mysql = require('mysql2')

const db = mysql.createConnection({
  host: '172.17.0.1',     // change if needed
  user: 'root',           // change to your MySQL user
  password: '111111',     // change to your MySQL password
  database: 'vuln_nuxt2'  // ensure this DB exists
})

db.connect(err => {
  if (err) {
    console.error('❌ MySQL connection error:', err.message)
  } else {
    console.log('✅ Connected to MySQL')
  }
})

module.exports = db

