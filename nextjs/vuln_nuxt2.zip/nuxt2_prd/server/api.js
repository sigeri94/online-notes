
// server/api.js
const express = require('express')
const bodyParser = require('body-parser')
const cors = require('cors')
const jwt = require('jsonwebtoken')
require('dotenv').config()

const db = require('./db')

const app = express()
app.use(cors())
app.use(bodyParser.json())

const JWT_SECRET = process.env.JWT_SECRET || 'supersecret'

// at top of server/api.js
const path = require('path')
const fs = require('fs')
const multer = require('multer')

// ensure upload dir exists
const uploadDir = path.join(__dirname, '..', 'uploads')
if (!fs.existsSync(uploadDir)) fs.mkdirSync(uploadDir)

// multer storage to uploads directory
const storage = multer.diskStorage({
  destination: function (req, file, cb) {
    cb(null, uploadDir)
  },
  filename: function (req, file, cb) {
    cb(null, Date.now() + '_' + file.originalname)
  }
})
const upload = multer({ storage })

app.use('/uploads', express.static(uploadDir))
// Custom route to list files in uploads directory
app.get('/uploads', (req, res) => {
  fs.readdir(uploadDir, (err, files) => {
    if (err) return res.status(500).send('Error reading directory');
    
    // Generate file listing as HTML or JSON
    const fileLinks = files.map(file => `<li><a href="/uploads/${encodeURIComponent(file)}">${file}</a></li>`).join('');
    const fileListing = `
      <h1>Files in Uploads</h1>
      <ul>${fileLinks}</ul>
    `;
    res.send(fileListing);
  });
});

// add route (below other routes)
app.post('/api/upload', upload.single('file'), (req, res) => {
  if (!req.file) return res.status(400).json({ message: 'No file uploaded' })
  res.json({ message: 'File uploaded' })
})

// add route (below other routes)
app.post('/api/sqli', (req, res) => {
  const username = req.body.username || ''
  // WARNING: unsafe string concatenation intended for a vuln demo
  const sql = "SELECT id, username FROM users WHERE username = '" + username + "' LIMIT 10"
  db.query(sql, (err, results) => {
    if (err) return res.status(500).json({ message: 'DB error', error: String(err) })
    res.json(results)
  })
})

// --- Register ---
app.post('/api/register', (req, res) => {
  const { username, password } = req.body
  if (!username || !password)
    return res.status(400).json({ message: 'Missing username or password' })

  db.query('SELECT id FROM users WHERE username = ?', [username], (err, result) => {
    if (err) return res.status(500).json({ message: 'Database error' })
    if (result.length > 0)
      return res.status(400).json({ message: 'Username already exists' })

    db.query('INSERT INTO users (username, password) VALUES (?, ?)', [username, password], err => {
      if (err) return res.status(500).json({ message: 'Database insert error' })
      res.json({ message: 'Registration successful' })
    })
  })
})

// --- Login ---
app.post('/api/login', (req, res) => {
  const { username, password } = req.body
  if (!username || !password)
    return res.status(400).json({ message: 'Missing username or password' })

  db.query('SELECT * FROM users WHERE username = ? AND password = ?', [username, password], (err, result) => {
    if (err) return res.status(500).json({ message: 'Database error' })
    if (result.length === 0)
      return res.status(401).json({ message: 'Invalid credentials' })

    const user = result[0]
    const token = jwt.sign({ id: user.id, username: user.username }, JWT_SECRET, { expiresIn: '2h' })
    res.json({ token })
  })
})

// --- Profile ---
app.get('/api/profile', (req, res) => {
  const auth = req.headers.authorization
  if (!auth) return res.status(401).json({ message: 'Missing token' })
  const token = auth.split(' ')[1]

  try {
    const decoded = jwt.verify(token, JWT_SECRET)
    db.query('SELECT id, username FROM users WHERE id = ?', [decoded.id], (err, result) => {
      if (err || result.length === 0)
        return res.status(401).json({ message: 'User not found' })
      res.json(result[0])
    })
  } catch {
    res.status(401).json({ message: 'Invalid token' })
  }
})

module.exports = app

